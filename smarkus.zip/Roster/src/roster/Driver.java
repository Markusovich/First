package roster;

import java.io.IOException;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) throws IOException {

		Team t1 = new Team();  //Created object of Team class to reference it's methods later on
		
		Scanner scan = new Scanner(System.in);
		boolean b = true;
		int answer;
		
		while(b){
			System.out.println("To create a new roster, type 1");
			System.out.println("To add to an existing roster, type 2");
			System.out.println("To remove a player from a roster, type 3");
			int choice = scan.nextInt();
			if(choice == 1){
				t1.input();  //Calling input method in Team class
			}
			if(choice == 2){
				t1.add();  //Calling add method in Team class
			}
			if(choice == 3){
				t1.delete();  //Calling delete method in Team class
			}
			System.out.println();
			System.out.println("Quit? (0/1)");  //Asks us if we want to continue while loop to keep accessing methods
			answer = scan.nextInt();
			if(answer == 0){b=false;}
			else{b=true;}
		}
		scan.close();
		System.out.println("Done with program");  //End

	}

}

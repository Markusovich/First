package roster;

import java.io.IOException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) throws IOException {
		
			Team t1 = new Team();  //Created object of Team class to reference it's methods later on
	
			System.out.println(" _____________________________________________ ");
			System.out.println("|                  Welcome                    |");
			System.out.println("|---------------------------------------------|");
			System.out.println("| To create a new roster, type 1              |");
			System.out.println("| To add to an existing roster, type 2        |");
			System.out.println("| To remove a player from a roster, type 3    |");
			System.out.println("| To quit, type 4                             |");
			System.out.println("|_____________________________________________|");
	
			boolean done = false;
			Scanner input = new Scanner(System.in);
			while (!done) 
			{
				switch (input.nextInt())
				{
				case 1:
					t1.input();
					break;
				case 2:
					t1.add();
					break;
				case 3:
					t1.delete();
					break;
				case 4:
					done = true;
					System.out.println("End of program.");
					break;
				}
			}
			input.close();
	}
}

package roster;

import java.io.IOException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) throws IOException {

		Team t1 = new Team();
		System.out.println("To create a new roster, type 1");
		System.out.println("To add to an existing roster, type 2");
		
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		
		if(choice == 1){
			t1.input();
		}
		if(choice == 2){
			t1.add();
		}
		
		scan.close();
		
	}

}

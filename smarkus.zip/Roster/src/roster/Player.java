package roster;

public class Player {

	String fstname, lstname;
	
	public Player(String fstname_, String lstname_){
		fstname = fstname_;
		lstname = lstname_;
	}
	public String toString(){
		return fstname + " " + lstname;
	}
}

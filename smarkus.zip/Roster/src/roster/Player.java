package roster;

public class Player {

	String fstname, lstname, goals, caps, assists; //Defining variables
	
	public Player(String fstname, String lstname, String goals_, String caps_, String assists_) {
		super();
		this.fstname = fstname;  //Constructor for Player object
		this.lstname = lstname;  //Player object takes in 5 parameters
		this.goals = goals_;
		this.caps = caps_;
		this.assists = assists_;
	}
	public String toString(){
		return fstname + " " + lstname + " " + goals + " " + caps + " " + assists;
	}
	public String getFstname() {
		return fstname;
	}
	public String getLstname() {
		return lstname;
	}
	public String getGoals() {
		return goals;
	}
	public String getCaps() {
		return caps;
	}
	public String getAssists() {
		return assists;
	}
    public boolean equals(Object other) {  //Equals method
        if (this == other)				   //Compares one object with another, and determines if they are equal or not
            return true;
        if (other == null || getClass() != other.getClass())
            return false;
        Player player = (Player) other;
        return (fstname.equals(player.fstname) && lstname.equals(player.lstname));
    }
}

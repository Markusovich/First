package roster;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Team {
	
	public Team(){}
	
	Scanner scan = new Scanner(System.in);
	public void input() throws IOException {  //This method creates a file, and adds Players
		ArrayList<Player> x = new ArrayList<Player>();
		int num_people;
		System.out.print("Name of file (A file that does not exist will be automatically created): ");
		String name;
		name = scan.next();
		System.out.print("# of people on roster? ");
		num_people = scan.nextInt();
		System.out.println("Enter first name, last name, goals scored, appearances, and assists:");
		for(int i=0; i<num_people; i++){
			String fstname2 = scan.next();
			String lstname2 = scan.next();
			int goals = scan.nextInt();
			int caps = scan.nextInt();
			int assists = scan.nextInt();
			x.add(new Player(fstname2,lstname2,goals,caps,assists));  //Adds Player every time for loop increments
		}
		System.out.println("Done.");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(name));  //Opens file entered from keyboard
	    for(Player p : x)
	        if(p != null){
	            writer.write(p + "\n");  //Adds Players from ArrayList to file, line by line
	            writer.newLine();
	        }
	    writer.close();
	}
	public void add() throws IOException {  //This method adds new Players to an existing file
		ArrayList<Player> x = new ArrayList<Player>();
		System.out.println("Enter the name of the file that you wish to add information to: ");
		String name = scan.next();
		File w = new File(name);
		if(w.exists())
		{
		    System.out.println("How many people would you like to add? ");
			int num_people = scan.nextInt();
			System.out.println("Enter first name, last name, goals scored, appearances, and assists:");
			for(int i=0; i<num_people; i++){
				String fstname2 = scan.next();
				String lstname2 = scan.next();
				int goals = scan.nextInt();
				int caps = scan.nextInt();
				int assists = scan.nextInt();
				x.add(new Player(fstname2,lstname2,goals,caps,assists));   //Creates ArrayList of Players added*
			}
			System.out.println("Done.");
			
			BufferedWriter q = new BufferedWriter(new FileWriter(w, true));  //Adds Players from ArrayList to file
		    for(Player p : x){
		    	q.write(p + "\n");
		    	q.newLine();
		    }
		    q.close();
		}
		else{
			System.out.println("File does not exist.");
		}
	}
	
	public void delete() throws IOException {   //This method enables the user to remove a Player 
												//from an existing file
		ArrayList<Player> x = new ArrayList<Player>();
		System.out.println("Enter the name of the file that you wish to delete information from: ");
		String name = scan.next();
		File w = new File(name);
		if(w.exists())
		{
			try{
				FileReader fr = new FileReader(name);
				BufferedReader br = new BufferedReader(fr);
				Scanner read = new Scanner(br);
				while (read.hasNext()) {
					x.add(new Player(read.next(), read.next(), read.nextInt(), read.nextInt(), read.nextInt()));
				}
			}
				catch (IOException ex) {
				       System.out.println("Unable to open student file." + ex.toString());
				    }
			System.out.println("Size of Player ArrayList: " + x.size());
			System.out.println();

			for(int i=0;i<x.size();i++){
		    	System.out.println(x.get(i));  //Prints out the content in ArrayList
		    }

		    System.out.println("How many people would you like to remove? ");
			int num_people = scan.nextInt();
			System.out.println("Enter first name, last name, goals scored, appearances, and assists:");
			for(int i=0; i<num_people; i++){
				String fstname2 = scan.next();
				String lstname2 = scan.next();
				int goals = scan.nextInt();
				int caps = scan.nextInt();
				int assists = scan.nextInt();
				Player y = new Player(fstname2,lstname2,goals,caps,assists);  //Creates new Player
				
				for(int j=0;j<x.size();j++){		//For loop that compares each
					if(y.equals(x.get(j)) == true){	//Player in ArrayList to the Player
						x.remove(x.get(j));			//you just entered in
					}														  
			    }								//If the Player that you wish to delete matches with 
			}									//any of the Players in the ArrayList (by first and last name),
												//that Player that is identical to the one you chose is removed.
			System.out.println("Done.");
			System.out.println();
			for(int i=0;i<x.size();i++){
		    	System.out.println(x.get(i));
		    }
			BufferedWriter q = new BufferedWriter(new FileWriter(w));  //Overwriting the file with the new,
		    for(Player p : x){										   //shorter ArrayList.
		    	q.write(p + "\n");
		    	q.newLine();
		    }
		    q.close();
		}
		else{
			System.out.println("File does not exist.");
        }
	}
}
package roster;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Team {
	
	ArrayList<Player> x = new ArrayList<Player>();

	public Team(){
		this.x = new ArrayList<>();
	}
	Scanner scan = new Scanner(System.in);
	public void input() throws IOException {
		int num_people;
		System.out.print("Name of file (A file that does not exist will be automatically created): ");
		String name;
		name = scan.next();
		System.out.print("# of people on roster? ");
		num_people = scan.nextInt();
		System.out.println("Enter each first and last name with spaces until finished:");
		for(int i=0; i<num_people; i++){
			String fstname2 = scan.next();
			String lstname2 = scan.next();
			x.add(new Player(fstname2,lstname2));
		}
		scan.close();
		System.out.println("Done.");
		BufferedWriter writer = new BufferedWriter(new FileWriter(name));
		writer.write("Number of people: " + num_people + "\n");
		writer.newLine();
	    for(Player p : x)
	        if(p != null){
	            writer.write(p + "\n");
	            writer.newLine();
	        }
	    writer.close();
	}
	public void add() throws IOException {
		System.out.println("Enter the name of the file that you wish to add information to: ");
		String name = scan.next();
		File w = new File(name);
		if(w.exists())
		{
		    System.out.println("How many people would you like to add? ");
			int num_people = scan.nextInt();
			System.out.println("Enter each first and last name with spaces until finished:");
			for(int i=0; i<num_people; i++){
				String fstname2 = scan.next();
				String lstname2 = scan.next();
				x.add(new Player(fstname2,lstname2));
			}
			System.out.println("Done.");
			BufferedWriter q = new BufferedWriter(new FileWriter(w, true));
		    for(Player p : x){
		    	q.write(p + "\n");
		    	q.newLine();
		    }
		    q.close();
		}
		else{
			System.out.println("File does not exist.");
		}
	}

}
